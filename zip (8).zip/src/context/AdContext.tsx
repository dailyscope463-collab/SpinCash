import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { AdMob, RewardAdOptions, AdMobRewardItem } from '@capacitor-community/admob';
import { useToast } from "../components/ui/Toast";

interface AdContextType {
  showAd: (onComplete: () => void, onCancel?: () => void) => void;
}

const AdContext = createContext<AdContextType | undefined>(undefined);

export function useAd() {
  const context = useContext(AdContext);
  if (!context) throw new Error("useAd must be used within AdProvider");
  return context;
}

export function AdProvider({ children }: { children: ReactNode }) {
  const { showToast } = useToast();
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const initAdMob = async () => {
      try {
        await AdMob.initialize({});
        setIsInitialized(true);
        loadAd();
        
        AdMob.addListener('onRewardedVideoAdDismissed', () => {
          loadAd(); // Preload next ad
        });
      } catch (e) {
        console.error("AdMob Init Error", e);
      }
    };
    initAdMob();
    
    return () => {
      AdMob.removeAllListeners().catch(() => {});
    };
  }, []);

  const loadAd = async () => {
    try {
      const options: RewardAdOptions = {
        adId: 'ca-app-pub-9352983809793592/7213743820',
      };
      await AdMob.prepareRewardVideoAd(options);
    } catch (e) {
      console.error("Load Ad Error", e);
    }
  };

  const showAd = async (onComplete: () => void, onCancel?: () => void) => {
    try {
      let rewarded = false;
      
      const rewardListener = AdMob.addListener('onRewardedVideoAdReward', (rewardItem: AdMobRewardItem) => {
        rewarded = true;
        onComplete();
        rewardListener.remove();
      });

      const dismissListener = AdMob.addListener('onRewardedVideoAdDismissed', () => {
        if (!rewarded && onCancel) {
          onCancel();
        }
        dismissListener.remove();
      });

      await AdMob.showRewardVideoAd();
    } catch (e) {
      console.error(e);
      // Fallback for web or if ad fails to load
      showToast("Ad not available. Please try again later.", "error");
      if (onCancel) onCancel();
    }
  };

  return (
    <AdContext.Provider value={{ showAd }}>
      {children}
    </AdContext.Provider>
  );
}
